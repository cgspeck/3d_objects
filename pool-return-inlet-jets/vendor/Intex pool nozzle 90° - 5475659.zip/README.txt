Intex pool nozzle 90° by fauldrache on Thingiverse: https://www.thingiverse.com/thing:5475659

Summary:
pool nozzle with "Dyson Bladeless Fan"- Style90° outlet with center bore hole for more water flowworks good, prints without supportsI also added the SolidWorks and stepfile, if you want to remix it.Have fun,Sebastian